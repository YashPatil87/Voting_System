package com.votingsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VotingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
